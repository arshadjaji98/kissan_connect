import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'routes.dart';
import 'screens/WelcomeScreen.dart';
import 'screens/SignupScreen.dart';
import 'screens/LoginScreen.dart';
import 'screens/HomeScreen.dart';
import 'screens/auth_wrapper.dart';
import 'services/firebase_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final firebaseService = FirebaseService();

    return MaterialApp(
      title: 'Kissan Connect',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: Colors.white,
        fontFamily: 'Google Sans Flex',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4CAF50),
          primary: const Color(0xFF4CAF50),
          secondary: const Color(0xFF8BC34A),
        ),
        appBarTheme: const AppBarTheme(
          elevation: 0,
          centerTitle: false,
          titleTextStyle: TextStyle(
            color: Colors.black,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            fontFamily: 'Google Sans Flex',
          ),
          iconTheme: IconThemeData(color: Colors.black),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Colors.grey),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Colors.grey),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Color(0xFF4CAF50), width: 2),
          ),
          errorBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
            borderSide: BorderSide(color: Colors.red),
          ),
          focusedErrorBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
            borderSide: BorderSide(color: Colors.red, width: 2),
          ),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF4CAF50),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            textStyle: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              fontFamily: 'Google Sans Flex',
            ),
          ),
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            foregroundColor: const Color(0xFF4CAF50),
            textStyle: const TextStyle(
              fontWeight: FontWeight.w500,
              fontFamily: 'Google Sans Flex',
            ),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: const Color(0xFF4CAF50),
            side: const BorderSide(color: Color(0xFF4CAF50)),
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            textStyle: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              fontFamily: 'Google Sans Flex',
            ),
          ),
        ),
      ),

      // Use AuthWrapper as home (removes the need for welcome route in routes)
      home: AuthWrapper(firebaseService: firebaseService),

      // Only define routes that are NOT handled by AuthWrapper
      routes: {
        // REMOVED: AppRoutes.welcome from here since AuthWrapper handles it
        AppRoutes.signup: (context) => SignupScreen(firebaseService: FirebaseService()),
        AppRoutes.login: (context) => LoginScreen(firebaseService: FirebaseService()),
      },

      // Keep onGenerateRoute for HomeScreen with arguments
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case AppRoutes.home:
            final args = settings.arguments as Map<String, dynamic>?;

            List<String> selectedCrops = ['Wheat'];
            if (args?['selectedCrops'] != null) {
              if (args!['selectedCrops'] is List<String>) {
                selectedCrops = args['selectedCrops'] as List<String>;
              } else if (args['selectedCrops'] is List) {
                selectedCrops = List<String>.from(args['selectedCrops']);
              }
            }

            String primaryCrop = args?['primaryCrop']?.toString() ??
                (selectedCrops.isNotEmpty ? selectedCrops.first : 'Wheat');

            return MaterialPageRoute(
              builder: (_) => HomeScreen(
                userLocation: args?['userLocation']?.toString() ?? 'Your Location',
                selectedCrops: selectedCrops,
                primaryCrop: primaryCrop,
                userName: args?['userName']?.toString() ?? 'Farmer',
              ),
            );
          default:
            return null; // Let Flutter use the routes table or home
        }
      },
    );
  }
}