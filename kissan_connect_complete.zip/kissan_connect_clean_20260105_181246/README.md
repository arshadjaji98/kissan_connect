import 'package:flutter/material.dart';

void main() {
runApp(KissanConnect());
}

class KissanConnect extends StatelessWidget {
@override
Widget build(BuildContext context) {
return MaterialApp(
debugShowCheckedModeBanner: false,
title: "Kissan Connect",
home: WelcomeScreen(),
routes: {
'/welcome': (context) => WelcomeScreen(),
'/signup': (context) => SignupScreen(),
'/home': (context) => HomeScreen(),
},
);
}
}

class WelcomeScreen extends StatelessWidget {
@override
Widget build(BuildContext context) {
return Scaffold(
backgroundColor: Color(0xFFEFFAF1),
body: Padding(
padding: EdgeInsets.all(20),
child: Column(
mainAxisAlignment: MainAxisAlignment.center,
children: [
CircleAvatar(
radius: 50,
backgroundColor: Colors.green.shade100,
child: Icon(Icons.agriculture, color: Colors.green, size: 50),
),
SizedBox(height: 20),
Text("Kissan Connect", style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
SizedBox(height: 150),
ElevatedButton(
style: ElevatedButton.styleFrom(
backgroundColor: Colors.green,
minimumSize: Size(double.infinity, 55),
),
onPressed: () => Navigator.pushNamed(context, '/signup'),
child: Text("Sign Up"),
),
SizedBox(height: 15),
OutlinedButton(
style: OutlinedButton.styleFrom(
minimumSize: Size(double.infinity, 55),
side: BorderSide(color: Colors.green, width: 2),
),
onPressed: () {},
child: Text("Login", style: TextStyle(color: Colors.green)),
)
],
),
),
);
}
}

class SignupScreen extends StatefulWidget {
@override
State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
final crops = ["Wheat", "Rice", "Cotton", "Sugarcane", "Maize"];
List<String> selected = [];

@override
Widget build(BuildContext context) {
return Scaffold(
backgroundColor: Colors.brown.shade50,
appBar: AppBar(
title: Text("Create Your Account", style: TextStyle(color: Colors.black)),
backgroundColor: Colors.white,
elevation: 0,
leading: BackButton(color: Colors.black),
),
body: SingleChildScrollView(
padding: EdgeInsets.all(20),
child: Column(
children: [
_field("Full Name"),
_field("CNIC"),
_field("Email"),
_field("Password", obscure: true),
_field("Farm Location"),
_field("Land Area (Acres)"),
SizedBox(height: 15),
Text("Select Crops", style: TextStyle(fontWeight: FontWeight.bold)),
SizedBox(height: 10),
Wrap(
spacing: 10,
children: crops.map((c) {
bool s = selected.contains(c);
return ChoiceChip(
label: Text(c),
selected: s,
onSelected: (v) {
setState(() {
s ? selected.remove(c) : selected.add(c);
});
},
selectedColor: Colors.green.shade200,
);
}).toList(),
),
SizedBox(height: 20),
ElevatedButton(
onPressed: () => Navigator.pushNamed(context, '/home'),
style: ElevatedButton.styleFrom(
backgroundColor: Colors.green,
minimumSize: Size(double.infinity, 55),
),
child: Text("Sign Up"),
),
],
),
),
);
}

Widget _field(String label, {bool obscure = false}) {
return Padding(
padding: EdgeInsets.only(bottom: 10),
child: TextField(
obscureText: obscure,
decoration: InputDecoration(
labelText: label,
border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
),
),
);
}
}

class HomeScreen extends StatelessWidget {
@override
Widget build(BuildContext context) {
return Scaffold(
backgroundColor: Colors.grey.shade100,
appBar: AppBar(
backgroundColor: Colors.white,
title: Text("Kissan Connect", style: TextStyle(color: Colors.black)),
elevation: 0,
),
body: Center(
child: Text(
"Dashboard Coming Soon",
style: TextStyle(fontSize: 20),
),
),
);
}
}
